dbus.decorators module
----------------------

.. automodule:: dbus.decorators
    :members:
    :undoc-members:
    :show-inheritance:
