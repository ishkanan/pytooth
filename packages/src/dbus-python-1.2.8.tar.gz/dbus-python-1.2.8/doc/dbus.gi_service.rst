dbus.gi\_service module
-----------------------

.. automodule:: dbus.gi_service
    :members:
    :undoc-members:
    :show-inheritance:
