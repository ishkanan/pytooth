dbus.proxies module
-------------------

.. automodule:: dbus.proxies
    :members:
    :undoc-members:
    :show-inheritance:
