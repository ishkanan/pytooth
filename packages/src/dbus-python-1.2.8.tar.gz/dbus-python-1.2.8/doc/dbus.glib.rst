dbus.glib module
----------------

.. automodule:: dbus.glib
    :members:
    :undoc-members:
    :show-inheritance:
