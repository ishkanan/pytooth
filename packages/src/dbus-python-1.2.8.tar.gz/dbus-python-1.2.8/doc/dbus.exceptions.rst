dbus.exceptions module
----------------------

.. automodule:: dbus.exceptions
    :members:
    :undoc-members:
    :show-inheritance:
