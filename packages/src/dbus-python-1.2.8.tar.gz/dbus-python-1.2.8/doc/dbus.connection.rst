dbus.connection module
======================

.. automodule:: dbus.connection
    :members:
    :undoc-members:
    :show-inheritance:
